#!/bin/bash

# compress
rm "library.zip"
zip -FS -r "library.zip" .